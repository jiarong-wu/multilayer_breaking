// Generated automatically by gotm.awk from
// /home/popinet/local/src/code-5.2.1//src/meanflow/extpressure.F90

extern void extpressure_ (
  integer * method,
  integer * nlev
);
static inline void meanflow_extpressure (
  integer * method,
  integer * nlev) {
  extpressure_ (method, nlev);
}

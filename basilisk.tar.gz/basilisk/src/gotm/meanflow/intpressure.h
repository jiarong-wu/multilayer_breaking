// Generated automatically by gotm.awk from
// /home/popinet/local/src/code-5.2.1//src/meanflow/intpressure.F90

extern void intpressure_ (
  integer * nlev
);
static inline void meanflow_intpressure (
  integer * nlev) {
  intpressure_ (nlev);
}

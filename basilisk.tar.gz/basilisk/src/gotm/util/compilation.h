// Generated automatically by gotm.awk from
// /home/popinet/local/src/code-5.2.1//src/util/compilation.F90

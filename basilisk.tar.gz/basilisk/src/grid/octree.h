#define dimension 3
#define GRIDNAME "Octree"
#include "tree.h"

void octree_methods() {
  tree_methods();
}

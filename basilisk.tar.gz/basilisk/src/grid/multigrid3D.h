#define dimension 3
#include "multigrid.h"
